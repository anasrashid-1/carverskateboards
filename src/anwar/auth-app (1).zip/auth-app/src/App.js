
import './App.css';
import { Outlet } from 'react-router-dom';


function App() {
  return (
    <div className="App">
      {/* <SignIn/> */}
      
      <Outlet />
     
    </div>
  );
}

export default App;
